How do you install?
First you extract "Add, Already Set Up For PS2 Joysticks Only" next next copy the 5 files and go to your game directory and paste it into the root folder.

Now done that you extract "GInputSA" throw or paste from within the "scripts" folder just .ini and .asi now copy models folder into the root folder of your game.

Sorry for my english.

Como que instala?
Primeiramente voce extrai "Add, Already Set Up For PS2 Joysticks Only" logo seguinte copie os 5 arquivos e vá em seu diretorio do seu game e cole dentro da pasta raiz.

Agora feito isto voce extrai "GInputSA" jogue ou cole da dentro da pasta "scripts" apenas .ini e .asi agora copie pasta models dentro da pasta raiz do seu game.

Credits
Silent - GInputSA.
Cleyton - Add, Already Set Up For PS2 Joysticks Only.

Este Mods Será Hospedado em Mediafire e GTAInside.
These Mods will be hosted on Mediafire and GTAInside.

Enjoy!

